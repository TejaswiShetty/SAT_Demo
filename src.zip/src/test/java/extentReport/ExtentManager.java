package extentReport;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {

	static ExtentReports extent;
    final static String fileName = "ExtentOutput.html";
    static String folderPath ="";
    public synchronized static ExtentReports getReporter() {
        if (extent == null) {
            extent = new ExtentReports(folderPath() + fileName, true);
           // extent.loadConfig(System.getProperty("user.dir") +".\\resources\\extent-config.xml");
        }
        return extent;
    }
   public static String folderPath() {
        if(folderPath.trim().isEmpty()){
            DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
    	    Date today = Calendar.getInstance().getTime();
    	    String reportDate = df.format(today);
            folderPath = "Output/ExtentReport/"+ "Run_" + reportDate + "/" ;
        }
    	return folderPath;
	}
}

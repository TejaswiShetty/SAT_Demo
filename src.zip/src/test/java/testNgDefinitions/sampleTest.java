package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.loadPropertyFile;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster {


    public void test79(ITestContext context) {
        before("Change Location Action Reasons - Pick list Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateChangeLocation();
        new pages.hcmapplication.changeLocation().modifyDetails();

        new pages.hcmapplication.employInformation().actionListPersonalAndEmployment();
        new pages.hcmapplication.homePage().signOut();
    }


    public void test78(ITestContext context) {
        before("Verify that all  Manage Salary Action are avaliable to choose");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();

        new pages.hcmapplication.homePage().signOut();
    }


    public void test80(ITestContext context) {
        before("Verify the Location Change of an Associate to any of the US offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateChangeLocation();
        new pages.hcmapplication.changeLocation().modifyDetails();

        new pages.hcmapplication.homePage().signOut();


    }

    public void test81(ITestContext context) {
        before("Verify the Location Change of an Associate to any of the international offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateChangeLocation();
        new pages.hcmapplication.changeLocation().modifyDetails();


        new pages.hcmapplication.homePage().signOut();
    }

    public void test82(ITestContext context) {
        before("Change Salary Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();

        new pages.hcmapplication.homePage().signOut();
    }

    @Test
    public void test86(ITestContext context) {
        before("Verify that all  Change Working Hours action reasons are avaliable to choose");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateChangeWorkingHours();
        new pages.hcmapplication.changeWorkingHours().modifyDetails();

        new pages.hcmapplication.homePage().signOut();
    }

    @Test
    public void test83(ITestContext context) {
        before("Verify to Change the Salary of an US Associate due to Anniversary reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }

    public void test84(ITestContext context) {
        before("Verify to Change the Salary of an US Associate due to Annual Merit Increase reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }

    public void test85(ITestContext context) {
        before("Change working hours Action Reasons - Pick list Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }


    public void test87(ITestContext context) {
        before("Verify to Change an Associate from US offices working hours");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateChangeWorkingHours();
        new pages.hcmapplication.changeWorkingHours().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }

    public void test88(ITestContext context) {
        before("Promotion/Demotion Action Reasons - Pick list Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }


    public void test89(ITestContext context) {
        before("Verify that Demotion of a Associate in US offices and the request should go to one up manager");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigatePromote();
        new pages.hcmapplication.promote().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }

    //
    public void test90(ITestContext context) {
        before("Verify that Demotion of a  Associate in International offices and the request should go to one up manager");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigatePromote();
        new pages.hcmapplication.promote().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }


    public void test91(ITestContext context) {
        before("Verify that Demotion of a  Associate in International offices and the request should go to one up manager");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigatePromote();
        new pages.hcmapplication.promote().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test92(ITestContext context) {
        before("Verify that Promotion of a Associate in International offices and the request should go to one up manager");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigatePromote();
        new pages.hcmapplication.promote().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }


    public void test93(ITestContext context) {
        before("Termination Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test94(ITestContext context) {
        before("Voluntary Termination Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test95(ITestContext context) {
        before("Involuntary Termination Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test96(ITestContext context) {
        before("Verify to  Terminate a US Associate with Action as Voluntary and Any of the Action Reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test97(ITestContext context) {
        before("Verify to Terminate a international Associate with Action as Voluntary and Any of the Action Reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test98(ITestContext context) {
        before("Verify to Terminate a US Associate with Action as Involuntary and Any of the Action Reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test99(ITestContext context) {
        before("Verify toTerminate a international Associate with Action as Involuntary and Any of the Action Reason");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test100(ITestContext context) {
        before("Verify to Correct a Termination effective date");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTerminate();
        new pages.hcmapplication.terminate().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test102(ITestContext context) {
        before("Manage Direct Reports Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageDirectReports();
        new pages.hcmapplication.manageDirectReports().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test103(ITestContext context) {
        before("Verify  to Change Manager of an Associate to any of the US offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageDirectReports();
        new pages.hcmapplication.manageDirectReports().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test104(ITestContext context) {
        before("Verify to Change Manager of an Associate to any of the international offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateManageDirectReports();
        new pages.hcmapplication.manageDirectReports().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }


    public void test105(ITestContext context) throws Exception{
        before("Transfer Action Reasons - Pick list Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTransfer();
        new pages.hcmapplication.transfer().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }


    public void test236(ITestContext context) throws Exception{
        before("Verify the Transfer of an Associate within US offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTransfer();
        new pages.hcmapplication.transfer().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }

    public void test237(ITestContext context) throws Exception{
        before("Verify the Transfer of an Associate within international offices");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateTransfer();
        new pages.hcmapplication.transfer().modifyDetails();
        new pages.hcmapplication.homePage().signOut();

    }


   // 
    public void test106(ITestContext context) {
        before("Change Manager Action Reasons - Picklist Validation");
        driver wDriver = new driver();
        WebDriver driver = wDriver.getDriver();
        testData data = new testData();

        loadPropertyFile applicationProperty = new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window = driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        driver.manage().window().maximize();
        for (String windowHandler : driver.getWindowHandles()) {
            if (Parent_Window != windowHandler) {
                driver.switchTo().window(windowHandler);
            }
        }
        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));
        new pages.hcmapplication.employInformation().navigateChangeManager();
        new pages.hcmapplication.changeManager().modifyDetails();
        new pages.hcmapplication.homePage().signOut();
    }
}
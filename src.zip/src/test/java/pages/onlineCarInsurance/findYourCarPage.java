package pages.onlineCarInsurance;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import org.openqa.selenium.By;


public class findYourCarPage {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private By policyStartDatePicker = By.id("policyStartDatePicker");
    private By vehicleYearOfManufactureList = By.id("vehicleYearOfManufactureList");
    private By vehicleMakeList =By.id("vehicleMakeList");
    private By vehicleModelList=By.id("vehicleModelList");
    private By vehicleTransmissionList = By.id("vehicleTransmissionList");
    private By vehicleNumberOfCylindersList=By.id("vehicleNumberOfCylindersList");
    private By vehicleBodyTypeList= By.id("vehicleBodyTypeList");
    private By findCarButton = By.id("findcar");

    public boolean enterPolicyStartDatePicker(){
        ExtentTestManager.getTest().log(LogStatus.INFO, "scenario started...");
        return true;
    }

}

package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class changeLocation {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    private testData data=new testData();

    private By byChangeLocationDate = By.xpath("//*[contains(@id,'id1::content')]");
    private By byChangeLocationAction = By.xpath("//*[contains(@id,'ap1:soc1::content')]");
    private By byChangeLocationReason = By.xpath("//*[contains(@id,'ap1:soc2::content')]");


    private By byLocationIndicator = By.xpath("//*[contains(@id,'locationId::lovIconId')]");
    private By byLocationSearch = By.xpath("//*[contains(@id,'locationId::dropdownPopup::popupsearch')]");
    private By byLocationNameTextBox =By.xpath("//*[contains(@id,'locationId::_afrLovInternalQueryId:value00::content')]");
    private By bySearchButton = By.xpath("//button[contains(text(),'Search')]");
    private By bySearchRow= By.xpath("//div[contains(@id, 'locationId_afrLovInternalTableId')][2]/table//table/tbody/tr");
    private By byOkButton=By.xpath("//button[contains(text(), 'OK')][contains(@id, 'locationId::lovDialogId::ok')]");



    private By bySaveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By bySaveWarningOkButton = By.xpath("//button[contains(@id, 'okWarningDialog')]");
    private By byCancelWarningOkButton = By.xpath("//button[contains(@id, 'cancelWarningDialog')]");

    public boolean modifyDetails(){
        String ChangeLocationDate = data.getTestData("Change Location Date") ;
        String ChangeLocationReason = data.getTestData("Change Location Reason") ;
        String locationDetails= data.getTestData("Location Details") ;
        String ChangeLocationAction= data.getTestData("Change Location Action");

        if( ChangeLocationDate != ""){
            if(commBeh.isExist(driver, byChangeLocationDate)){
                driver.findElement(byChangeLocationDate).clear();
                commBeh.type("Change Location Date", byChangeLocationDate, driver, ChangeLocationDate);
            }
        }

        if( ChangeLocationAction != ""){
            if(commBeh.isExist(driver, byChangeLocationAction)){
                //driver.findElement(byChangeLocationAction).clear();
                commBeh.selectValue("Change Location Action", byChangeLocationAction, driver, ChangeLocationAction);
            }
        }

        if( ChangeLocationReason != ""){
            if(commBeh.isExist(driver, byChangeLocationReason)){
                //driver.findElement(byChangeLocationReason).clear();
                commBeh.selectValue("Change Location Reason", byChangeLocationReason, driver, ChangeLocationReason);
            }
        }

        if( locationDetails != ""){
            if(commBeh.isExist(driver, byLocationIndicator)){
                commBeh.click("Location Indicator" ,byLocationIndicator, driver );
                if(commBeh.isExist(driver, byLocationSearch)){
                    commBeh.click("Location Search" ,byLocationSearch, driver );
                    commBeh.type("Location Name", byLocationNameTextBox, driver, locationDetails);
                    commBeh.click("Search button", bySearchButton, driver);
                    commBeh.click("Search Row", bySearchRow, driver);
                    commBeh.click("Search Ok button", byOkButton, driver);
                }
            }
        }

        commBeh.click("Save button",bySaveButton, driver );

        commBeh.click("Confirmation Ok button",bySaveWarningOkButton, driver );

        return true;
    }

}

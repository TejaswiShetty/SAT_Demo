package pages.hcmapplication;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class homePage {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();

    private By navigatorIcon = By.xpath("//*[@title='Navigator']");
    private By navigatorTable = By.xpath("//*[@id='__af_Z_window']");
    private By navigatorMyTeam =By.xpath("//a[contains(text(), 'My Team')] [@id='pt1:nv_PER_HCMPEOPLETOP_FUSE_MY_TEAM']");
    private By visionTitle= By.xpath("//*[@id='pt1:_UIScil1u']");
    private By signOutIcon= By.xpath("//*[@id='_FOpt1:_UIScmil1u']");
    private By signOutLink=By.xpath("//*[@id='_FOpt1:_UISlg1']");
    private By signOutWarning=By.xpath("//button[contains(@id, '_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAyes')][contains(text(), 'Yes')]");

    private By teamMemberXpath (String name){
        return By.xpath("//a[contains(text(), '"+ name+"')]");
    }


    public boolean navigateToMyTeam(){

        if(commBeh.isExist(driver,navigatorIcon )){
            commBeh.click("Navigator icon", navigatorIcon, driver);
            if(commBeh.isExist(driver,navigatorTable )){
                commBeh.click("Navigator My Team", navigatorMyTeam, driver);
            }
        }
        commBeh.reportScreenshot(driver);
        return commBeh.isExist(driver, visionTitle);
    }

    public boolean signOut(){
        if(commBeh.isExist(driver,signOutIcon )){
            commBeh.jClick("Sign Out icon", signOutIcon, driver);
            if(commBeh.isExist(driver,signOutLink )){
                commBeh.jClick("Sign Out Link", signOutLink, driver);
            }
            if(commBeh.isExist(driver,signOutWarning)){
                commBeh.jClick("Sign Out Warning", signOutWarning, driver);
            }
        }
        commBeh.reportScreenshot(driver);
        return !commBeh.isExist(driver, visionTitle);
    }

    public boolean teamMemberSelection(String teamMember){
        if(commBeh.isExist(driver,teamMemberXpath(teamMember) )){
            commBeh.click("Team Member Link : "  + teamMember ,teamMemberXpath(teamMember), driver);
        }
        return true;
    }
}

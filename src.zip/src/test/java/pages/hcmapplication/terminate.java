package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Vinaykumar_P03 on 7/20/2017.
 */
public class terminate {

    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    //private By terminateAction =By.xpath("//input[contains(@id, 'idEffectiveFromDate::content')]");

    private By terminateActionDDL = By.xpath("//*[contains(@id,'Action')][1]/td[2]/select");
    private By notificationDate = By.xpath("//*[contains(@id,'NotificationDate')][1]/td[2]/input");
    private By terminationDate = By.xpath("//*[contains(@id,'TerminationDate')][1]/td[2]/input[1]");
    private By terminateReasonDDL = By.xpath("//*[contains(@id,'selectOneChoice2')][1]/td[2]/select");
    private By dateOfDeath = By.xpath("//*[contains(@id,'id1')][1]/td[2]/input[1]");
    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");

    public boolean modifyDetails() {

        String TerminateAction = data.getTestData("Terminate Action");
        String NotificationDate = data.getTestData("Notification Date");
        String TerminationDate = data.getTestData("Termination Date");
        String TerminateReason = data.getTestData("Terminate Reason");
        String DateOfDeath = data.getTestData("Date of Death");

        if( TerminateAction != ""){
            if(commBeh.isExist(driver, terminateActionDDL)){
                //driver.findElement(terminateActionDDL).clear();
                commBeh.selectValue("Terminate Action", terminateActionDDL, driver, TerminateAction);
            }
        }

        commBeh.explicitWait(5);

        if( TerminateReason != ""){
            if(commBeh.isExist(driver, terminateReasonDDL)){
                // driver.findElement(terminateReasonDDL).clear();
                commBeh.selectValue("Terminate Reason", terminateReasonDDL, driver, TerminateReason);
            }
        }


        if( NotificationDate != ""){
            if(commBeh.isExist(driver, notificationDate)){
                driver.findElement(notificationDate).clear();
                commBeh.type("Notification Date", notificationDate, driver, NotificationDate);
            }
        }

        commBeh.explicitWait(5);

        if( TerminationDate != ""){
            if(commBeh.isExist(driver, terminationDate)){
                driver.findElement(terminationDate).clear();
                commBeh.type("Termination Date", terminationDate, driver, TerminationDate);
            }
        }

        commBeh.explicitWait(5);

        if( TerminationDate != ""){
            if(commBeh.isExist(driver, terminationDate)){
                driver.findElement(terminationDate).clear();
                commBeh.type("Termination Date", terminationDate, driver, TerminationDate);
            }
        }

        if( DateOfDeath != ""){
            if(commBeh.isExist(driver, dateOfDeath)){
                driver.findElement(dateOfDeath).clear();
                commBeh.type("Date of Death", dateOfDeath, driver, DateOfDeath);
            }
        }
        commBeh.explicitWait(2);

        if( DateOfDeath != ""){
            if(commBeh.isExist(driver, dateOfDeath)){
                driver.findElement(dateOfDeath).clear();
                commBeh.type("Date of Death", dateOfDeath, driver, DateOfDeath);
            }
        }

        commBeh.click("Save button",saveButton, driver );

        commBeh.jClick("Confirmation Ok button",confirmationOk, driver );

        return true;

    }
}

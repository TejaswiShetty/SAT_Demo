package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Vinaykumar_P03 on 7/18/2017.
 */
public class changeWorkingHours {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By saveButtonWarning = By.xpath(".//*[contains(@id,'okWarningDialog')]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By changeWorkingHourDate = By.xpath(".//*[contains(@id,'id1::content')]");
    private By changeWorkingHoursAction = By.xpath(".//*[contains(@id,'soc1::content')]");
    private By changeWorkingHoursReason = By.xpath(".//*[contains(@id,'soc2::content')]");
    private By warningChangeWorkingHoursDateOK = By.xpath(".//*[contains(@id,'MAnt2:1:r1:0:pt1:ap6:cb2')]");
    public boolean modifyDetails(){
        String ChangeWorkingHourDate = data.getTestData("Change Working Hours Date") ;
        String ChangeWorkingHourAction = data.getTestData("Change Working Hours Action") ;
        String ChangeWorkingHoursReason = data.getTestData("Change Working Hours Reason");

        if( ChangeWorkingHourDate != ""){
            if(commBeh.isExist(driver, changeWorkingHourDate)){
                driver.findElement(changeWorkingHourDate).clear();
                commBeh.type("Change Working Hours Date", changeWorkingHourDate, driver, ChangeWorkingHourDate);
            }
        }

        commBeh.passTab("Tab button",changeWorkingHourDate,driver);

        commBeh.explicitWait(5);
        if (commBeh.isExist(driver, warningChangeWorkingHoursDateOK)) {
            commBeh.click("Warning Change Working Hours Date OK", warningChangeWorkingHoursDateOK, driver);
        }
        commBeh.explicitWait(5);
        if( ChangeWorkingHourAction != ""){
            if(commBeh.isExist(driver, changeWorkingHoursAction)){
               // driver.findElement(changeWorkingHoursAction).clear();
                commBeh.selectValue("Change Working Hours Action", changeWorkingHoursAction, driver, ChangeWorkingHourAction);
            }
        }

        if( ChangeWorkingHoursReason != ""){
            if(commBeh.isExist(driver, changeWorkingHoursReason)){
                //driver.findElement(changeWorkingHoursReason).clear();
                commBeh.selectValue("Change Working Hours Reason", changeWorkingHoursReason, driver, ChangeWorkingHoursReason);
            }
        }

        commBeh.click("Save button",saveButton, driver );

        commBeh.explicitWait(2);
        if (commBeh.isExist(driver, saveButtonWarning)) {
            commBeh.click("Save Warning OK button", saveButtonWarning, driver);
            commBeh.explicitWait(2);
        }

        if (commBeh.isExist(driver, confirmationOk)) {
            commBeh.click("Confirmation Ok button",confirmationOk, driver );
        }

        return true;
    }
}

package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class manageSalary {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    private By newSalaryStartDate =By.xpath("//input[contains(@id, 'idEffectiveFromDate::content')]");

    private By actionDDL=By.xpath("//*[contains(@id, 'idAction::content')]");
    private By actionReasonDDL=By.xpath("//*[contains(@id, 'actionReasonNameId::content')]");

    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By warningSalaryButton = By.xpath(".//*[@id='_FOd1::msgDlg::cancel']");
    private By newSalaryBasisDDL = By.xpath("//*[contains(@id, 'idNewSalaryBasis::content')]");
    private By newSalary = By.xpath("//input[contains(@id, 'idSalaryAmount::content')]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By cancelSearch = By.xpath("//*[contains(@id,'actionReasonNameId::lovDialogId::cancel')]");
    public boolean modifyDetails(){
        String NewSalaryStartDate = data.getTestData("New Salary Start Date") ;
        String Action= data.getTestData("Action");
        String ActionReason = data.getTestData("Action Reason");
        String NewSalaryBasis = data.getTestData("New Salary Basis");
        String NewSalary = data.getTestData("New Salary");

        if( NewSalaryBasis != ""){
            if(commBeh.isExist(driver, newSalaryBasisDDL)){
                driver.findElement(newSalaryBasisDDL).clear();
                commBeh.type("New Salary Basis", newSalaryBasisDDL, driver, NewSalaryBasis);
            }
        }

        if( NewSalary != ""){
            if(commBeh.isExist(driver, newSalary)){
                driver.findElement(newSalary).clear();
                commBeh.type("New Salary", newSalary, driver, NewSalary);
            }
        }

        if(commBeh.isExist(driver, warningSalaryButton)){

            commBeh.click("Warning salary ok button",warningSalaryButton, driver );
        }

        if( NewSalaryStartDate != ""){
            if(commBeh.isExist(driver, newSalaryStartDate)){
                driver.findElement(newSalaryStartDate).clear();
                commBeh.type("New Salary Start Date", newSalaryStartDate, driver, NewSalaryStartDate);
            }
        }

        if( Action != ""){
            if(commBeh.isExist(driver, actionDDL)){
                driver.findElement(actionDDL).clear();
                commBeh.type("Action", actionDDL, driver, Action);
            }
        }

        commBeh.explicitWait(2);

        if( Action != ""){
            if(commBeh.isExist(driver, actionDDL)){
                driver.findElement(actionDDL).clear();
                commBeh.type("Action", actionDDL, driver, Action);
            }
        }

        if( ActionReason != ""){
            if(commBeh.isExist(driver, actionReasonDDL)){
                driver.findElement(actionReasonDDL).clear();
                commBeh.type("Action Reason", actionReasonDDL, driver, ActionReason);
            }
        }
        commBeh.explicitWait(2);

        commBeh.click("Cancel search button",cancelSearch, driver );

        commBeh.explicitWait(2);

        if( ActionReason != ""){
            if(commBeh.isExist(driver, actionReasonDDL)){
                driver.findElement(actionReasonDDL).clear();
                commBeh.type("Action Reason", actionReasonDDL, driver, ActionReason);
            }
        }
        commBeh.explicitWait(2);
        commBeh.click("Cancel search button",cancelSearch, driver );

        commBeh.click("Save button",saveButton, driver );

        commBeh.jClick("Confirmation Ok button",confirmationOk, driver );

        return true;
    }
}

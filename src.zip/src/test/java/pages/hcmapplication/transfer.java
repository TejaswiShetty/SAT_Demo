package pages.hcmapplication;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by vinaykumar_P03 on 7/21/2017.
 */
public class transfer {

    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    private By transferDate = By.xpath("//*[contains(@id,'effectiveDate1')][1]/td[2]/input");
    private By transferActionDDL = By.xpath("//*[contains(@id,'selectOneChoice1')][1]/td[2]/select");
    private By transferReasonDDL = By.xpath("//*[contains(@id,'selectOneChoice2')][1]/td[2]/select");
    private By businessUnitDDL = By.xpath("//*[contains(@id,'businessUnit1Id')][1]/td[2]/span/input");
    private By positionDDL = By.xpath("//*[contains(@id,'position1Id::lovIconId')]");
    private By jobDDL = By.xpath("//*[contains(@id,'job1Id')][1]/td[2]/span/input");
    private By nextButton = By.xpath(".//*[@class='xyl'][2]/button");
    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By searchLink = By.xpath(".//*[text() = 'Search...']");
    private By positionNameTextBox = By.cssSelector("[name='_FOpt1:_FOr1:0:_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAnt2:1:r1:0:pt1:ap1:JobDe1:0:position1Id::_afrLovInternalQueryId:value00']");
    private By searchButton = By.cssSelector("[[id='_FOpt1:_FOr1:0:_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAnt2:1:r1:0:pt1:ap1:JobDe1:0:position1Id::_afrLovInternalQueryId::search']");
    private By searchRow = By.xpath("//div[contains(@id, 'position1Id_afrLovInternalTableId')][2]/table//table/tbody/tr");
    private By okButton = By.xpath("//button[contains(text(), 'OK')][contains(@id, 'position1Id::lovDialogId::ok')]");

    private By warningOk =By.xpath("//button[contains(text(), 'Yes')]");
    public boolean modifyDetails() {
        String TransferDate = data.getTestData("Transfer Date");
        String TransferAction = data.getTestData("Transfer Action");
        String TransferReason = data.getTestData("Transfer Reason");
        String BusinessUnit = data.getTestData("Business Unit");
        String Position = data.getTestData("Position");
        String Job = data.getTestData("Job");



        if (TransferDate != "") {
            if (commBeh.isExist(driver, transferDate)) {
                driver.findElement(transferDate).clear();
                commBeh.type("Transfer Date", transferDate, driver, TransferDate);
            }
        }

        commBeh.passTab("Tab Button", transferDate, driver);

        commBeh.explicitWait(5);

        commBeh.click("Warning Ok button",warningOk, driver );

        if( TransferAction != ""){
            if(commBeh.isExist(driver, transferActionDDL)){
               // driver.findElement(transferActionDDL).clear();
                commBeh.selectValue("Transfer Action", transferActionDDL, driver, TransferAction);
            }
        }

        if( TransferReason != ""){
            if(commBeh.isExist(driver, transferReasonDDL)){
               // driver.findElement(transferReasonDDL).clear();
                commBeh.selectValue("Transfer Reason", transferReasonDDL, driver, TransferReason);
            }
        }

        commBeh.explicitWait(2);

        if (BusinessUnit != "") {
            if (commBeh.isExist(driver, businessUnitDDL)) {
                driver.findElement(businessUnitDDL).clear();
                commBeh.type("Business Unit", businessUnitDDL, driver, BusinessUnit);
            }
        }

        commBeh.explicitWait(2);

        if( Position != ""){
            if(commBeh.isExist(driver, positionDDL)){
                commBeh.click("Position DDL" ,positionDDL, driver );
                if(commBeh.isExist(driver, searchLink)){
                    commBeh.click("Search Link" ,searchLink, driver );
                    commBeh.type("Proposed Manager", positionNameTextBox, driver, Position);
                    commBeh.click("Search button", searchButton, driver);
                    commBeh.click("Search Row", searchRow, driver);
                    commBeh.click("Search Ok button", okButton, driver);
                }
            }
        }

        commBeh.explicitWait(2);

        if( Job != ""){
            if(commBeh.isExist(driver, jobDDL)){
               driver.findElement(jobDDL).clear();
                commBeh.type("Job", jobDDL, driver, Job);
            }
        }

        commBeh.passTab("Tab Button", transferDate, driver);

        commBeh.explicitWait(2);

        commBeh.click("Next button",nextButton, driver );

        commBeh.explicitWait(5);

        commBeh.click("Next button2",nextButton, driver );

        commBeh.explicitWait(7);

        commBeh.click("Next button3",nextButton, driver );

        commBeh.explicitWait(5);

        commBeh.click("Save button",saveButton, driver );

        commBeh.click("Confirmation Ok button",confirmationOk, driver );
        return true;
    }


}

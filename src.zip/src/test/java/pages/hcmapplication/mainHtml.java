package pages.hcmapplication;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class mainHtml {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();

    private By HCMCloudDirectLogin= By.xpath("//a[contains(text(), 'HCM Cloud Direct Login')]");

    public boolean navigateToHCMLoginPage(){
        ExtentTestManager.write(LogStatus.INFO, "Step 1","scenario started...");
        commBeh.click("HCM Cloud Direct Login", HCMCloudDirectLogin, driver);
        commBeh.screenshot(driver);
        return true;
    }

}

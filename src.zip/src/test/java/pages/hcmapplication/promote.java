package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.lang.Thread;
/**
 * Created by Vinaykumar_P03 on 7/19/2017.
 */
public class promote {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    private By promotionDate = By.xpath("//*[contains(@id,'effectiveDate::content')]");
    private By promotionActionDDL = By.xpath("//*[contains(@id,'ap1:selectOneChoice1::content')]");
    private By promotionReasonDDL = By.xpath("//*[contains(@id,'selectOneChoice2::content')]");
    private By nextButton = By.xpath(".//*[@class='xyl'][2]/button");
    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By warningOk =By.xpath("//button[contains(text(), 'Yes')]");
    public boolean modifyDetails() {

        String PromotionDate = data.getTestData("Promotion Date") ;
        String PromotionAction= data.getTestData("Promotion Action");
        String PromotionReason = data.getTestData("Promotion Reason");

        if( PromotionDate != ""){
            if(commBeh.isExist(driver, promotionDate)){
                driver.findElement(promotionDate).clear();
                commBeh.type("Promotion Date", promotionDate, driver, PromotionDate);
            }
        }

        commBeh.passTab("Tab Button", promotionDate, driver);

        commBeh.explicitWait(5);

        commBeh.click("Warning Ok button",warningOk, driver );

        if( PromotionAction != ""){
            if(commBeh.isExist(driver, promotionActionDDL)){
                //driver.findElement(promotionActionDDL).clear();
                commBeh.selectValue("Promotion Action", promotionActionDDL, driver, PromotionAction);
            }
        }

        if( PromotionReason != ""){
            if(commBeh.isExist(driver, promotionReasonDDL)){
                //driver.findElement(promotionReasonDDL).clear();
                commBeh.selectValue("Promotion Reason", promotionReasonDDL, driver, PromotionReason);
            }
        }

        commBeh.click("Next Button", nextButton, driver);

        commBeh.explicitWait(5);

        commBeh.click("Next Button", nextButton, driver);

        commBeh.explicitWait(5);

        commBeh.click("Next Button", nextButton, driver);

        commBeh.explicitWait(5);

        commBeh.click("Save button",saveButton, driver );

        commBeh.jClick("Confirmation Ok button",confirmationOk, driver );

        return true;

    }
}

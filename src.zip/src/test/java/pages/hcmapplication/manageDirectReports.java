package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Vinaykumar_P03 on 7/21/2017.
 */
public class manageDirectReports {

    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    private testData data=new testData();

    private By manageDirectReportsEffectiveDate = By.xpath("//*[contains(@id,'id1')][1]/td[2]/input");
    private By manageDirectReportsActionDDL = By.xpath("//*[contains(@id,'soc1')][1]/td[2]/select");
    private By manageDirectReportsReasonDDL = By.xpath("//*[contains(@id,'soc2')][1]/td[2]/select");
    private By saveButton=By.xpath(".//*[text() = 'Save']");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By proposedManagerDDL = By.xpath("//*[contains(@id,'managerNameId::lovIconId')]");
    private By searchLink = By.xpath(".//*[text() = 'Search...']");
    private By managerNameTextBox = By.xpath("//*[contains(@id,'managerNameId::_afrLovInternalQueryId:value00')]/input");
    private By searchButton = By.xpath("//*[contains(@id,'managerNameId::_afrLovInternalQueryId::search')]");
    private By searchRow = By.xpath("//div[contains(@id, 'managerNameId_afrLovInternalTableId')][2]/table//table/tbody/tr");
    private By okButton = By.xpath("//button[contains(text(), 'OK')][contains(@id, 'managerNameId::lovDialogId::ok')]");

    public boolean modifyDetails() {
        String ManageDirectReportsEffectiveDate = data.getTestData("Manage Direct Reports Effective Date");
        String ManageDirectReportsAction = data.getTestData("Manage Direct Reports Action");
        String ManageDirectReportsReason = data.getTestData("Manage Direct Reports Reason");
        String ProposedManager = data.getTestData("Proposed Manager");


        if (ManageDirectReportsEffectiveDate != "") {
            if (commBeh.isExist(driver, manageDirectReportsEffectiveDate)) {
                driver.findElement(manageDirectReportsEffectiveDate).clear();
                commBeh.type("Manage Direct Reports Effective Date", manageDirectReportsEffectiveDate, driver, ManageDirectReportsEffectiveDate);
            }
        }
        if( ManageDirectReportsAction != ""){
            if(commBeh.isExist(driver, manageDirectReportsActionDDL)){
                //driver.findElement(manageDirectReportsActionDDL).clear();
                commBeh.selectValue("Manage Direct Reports Action", manageDirectReportsActionDDL, driver, ManageDirectReportsAction);
            }
        }

        if( ManageDirectReportsReason != ""){
            if(commBeh.isExist(driver, manageDirectReportsReasonDDL)){
                //driver.findElement(manageDirectReportsReasonDDL).clear();
                commBeh.selectValue("Manage Direct Reports Reason", manageDirectReportsReasonDDL, driver, ManageDirectReportsReason);
            }
        }
        if( ProposedManager != ""){
            if(commBeh.isExist(driver, proposedManagerDDL)){
                commBeh.click("Proposed Manager DDl" ,proposedManagerDDL, driver );
                if(commBeh.isExist(driver, searchLink)){
                    commBeh.click("Search Link" ,searchLink, driver );
                    commBeh.type("Proposed Manager", managerNameTextBox, driver, ProposedManager);
                    commBeh.click("Search button", searchButton, driver);
                    commBeh.click("Search Row", searchRow, driver);
                    commBeh.click("Search Ok button", okButton, driver);
                }
            }
        }

        try {
            Thread.sleep(5000);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        commBeh.click("Save button",saveButton, driver );

        commBeh.click("Confirmation Ok button",confirmationOk, driver );

        return true;
    }
}
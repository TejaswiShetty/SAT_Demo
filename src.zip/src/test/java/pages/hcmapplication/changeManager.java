package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by vinaykumar_P03 on 7/24/2017.
 */
public class changeManager {

    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    //private By changeManagerDate = By.cssSelector("[name='_FOpt1:_FOr1:0:_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAnt2:1:r1:0:pt1:ap1:id1']");
    private By changeManagerDate = By.xpath("//*[contains(@id,'id1')][1]/td[2]/input");
    private By changeManagerActionDDL = By.xpath("//*[contains(@id,'soc1')][1]/td[2]/select");
    private By changeManagerReasonDDL = By.xpath("//*[contains(@id,'soc2')][1]/td[2]/select");
    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");
    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By warningOk =By.xpath("//*[contains(@id, 'okWarningDialog')]");

    public boolean modifyDetails() {
        String ChangeManagerDate = data.getTestData("Change Manager Date");
        String ChangeManagerAction = data.getTestData("Change Manager Action");
        String ChangeManagerReason = data.getTestData("Change Manager Reason");

        if (ChangeManagerDate != "") {
            if (commBeh.isExist(driver, changeManagerDate)) {
                driver.findElement(changeManagerDate).clear();
                commBeh.type("Transfer Date", changeManagerDate, driver, ChangeManagerDate);
            }
        }

        if( ChangeManagerAction != ""){
            if(commBeh.isExist(driver, changeManagerActionDDL)){
                //driver.findElement(changeManagerActionDDL).clear();
                commBeh.selectValue("Transfer Action", changeManagerActionDDL, driver, ChangeManagerAction);
            }
        }

        if( ChangeManagerReason != ""){
            if(commBeh.isExist(driver, changeManagerReasonDDL)){
                //driver.findElement(changeManagerReasonDDL).clear();
                commBeh.selectValue("Transfer Reason", changeManagerReasonDDL, driver, ChangeManagerReason);
            }
        }
        commBeh.click("Save button",saveButton, driver );
        commBeh.click("Warning Ok button",warningOk, driver );
        commBeh.click("Confirmation Ok button",confirmationOk, driver );
        return true;

    }
}

package cucumberStepDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import commonFunctions.ExcelReader;
import commonFunctions.loadPropertyFile;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import extentReport.ExtentManager;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import java.util.Collection;
import java.util.Map;

public class MasterStepdefs {
    Scenario scenario=null;
    @Before
    public void before(Scenario scenario){
        Collection<String> category = scenario.getSourceTagNames();
        ITestContext context = configurationManager.getITestContext();
        String testCaseName = "";
        ExtentTestManager.extent = ExtentManager.getReporter();
        Map<String, String> mDataRow = null;
        this.scenario =scenario;
        int count =1;
        try{
            if(! context.getCurrentXmlTest().getParameter("automationName").isEmpty()){
                testCaseName =context.getCurrentXmlTest().getParameter("automationName") + "_";
                testCaseName = testCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("automationName"));
            }
        }catch(Exception ex){

        }
        try {
            if (!context.getCurrentXmlTest().getParameter("environmentName").isEmpty()) {
                testCaseName = testCaseName + context.getCurrentXmlTest().getParameter("environmentName") + "_";
                category.add(context.getCurrentXmlTest().getParameter("environmentName"));
                testCaseName = testCaseName.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                testCaseName= testCaseName+ context.getCurrentXmlTest().getParameter("browserName");
                testCaseName=testCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("browserName"));
            }
        }catch(Exception ex){

        }

        try{
            if(testCaseName.trim().isEmpty()) {
                testCaseName= scenario.getName();
            } else {
                testCaseName= testCaseName+ "_"+ scenario.getName();
            }
        }catch(Exception ex){

        }

        do {
            if(configurationManager.testCaseNameList.contains(count +"_"+ testCaseName)) {
                count++;
            }else{
                configurationManager.testCaseNameList.add(count +"_"+ testCaseName);
                ExtentTestManager.startTest(count +"_"+ testCaseName);
                break;
            }
        }while(true);

        ExtentTestManager.assignCategory(category);
        ExtentTestManager.getTest().log(LogStatus.INFO, "scenario started..." + scenario.getName());
        configurationManager.setTestCaseName(scenario.getName());
        FolderName(scenario, context);

        ExcelReader reader = new ExcelReader();
        mDataRow=reader.readDataReturnMap(scenario.getName());
        configurationManager.setTestDataMap(mDataRow);
    }

    @After
    public void after(Scenario scenario) {
        CommonBehaviour comm = new CommonBehaviour();
        if (scenario.isFailed()) {
            ExtentTestManager.write(scenario, LogStatus.FAIL, "Test case failed");
            ITestContext context = configurationManager.getITestContext();
            String browserName = context.getCurrentXmlTest().getParameter("browserName");

            if(browserName.toLowerCase().contains("remote")){
                RemoteWebDriver remoteDriver = null;
                try{
                    remoteDriver = configurationManager.getRemoteWebDriver();
                }catch(Exception ex){

                }
                if(remoteDriver != null) {

                } else {
                    comm.reportScreenshot(remoteDriver);
                }
            } else {
                WebDriver driver = null;
                try{
                    driver = configurationManager.getWebDriver();
                }catch(Exception ex){

                }
                if(driver != null) {

                } else {
                    comm.reportScreenshot(driver);
                }
            }
        } else {
            ExtentTestManager.write(scenario, LogStatus.PASS, "Test passed");
        }
        comm.imageDocumentReport();
        ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
        ExtentManager.getReporter().flush();

    }

    private boolean FolderName(Scenario scenario, ITestContext context) {
        int count=1;
        String baseFolderPath = extentReport.ExtentManager.folderPath();

        String screenShotPath ="";
        try {
            if (!context.getCurrentXmlTest().getParameter("automationName").isEmpty()) {
                screenShotPath = context.getCurrentXmlTest().getParameter("automationName") + "\\";
                screenShotPath = screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("environmentName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("environmentName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("browserName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(screenShotPath.trim().isEmpty()) {
                screenShotPath= baseFolderPath + "\\";
            } else {
                screenShotPath = baseFolderPath + "\\"+ screenShotPath ;
            }
        }catch(Exception ex){

        }

        do {
            if(configurationManager.screenShotPathList.contains(screenShotPath + count + "_"+ scenario.getName() + "\\")) {
                count++;
            }else{
                configurationManager.screenShotPathList.add(screenShotPath + count + "_"+ scenario.getName() + "\\");
                configurationManager.setScreenShotPath(screenShotPath + count + "_"+ scenario.getName() + "\\");
                break;
            }
        }while(true);
        return true;
    }

}
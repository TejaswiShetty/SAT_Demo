package cucumberStepDefinitions;

import cucumber.api.testng.CucumberFeatureWrapper;
import extentReport.ExtentManager;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.*;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions( features = {"src/test/java/featureFile/LoginValidation.feature"},
		   format = {"pretty", "html:target/results1.html",  "json:target/result1.json"}
)

public class RunCukes {
	private TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun = true)
	public void setUpClass(ITestContext context) throws Exception {
        ExtentTestManager.extent = ExtentManager.getReporter();
		configurationManager.setITestContext(context);
		System.out.println("Parameter Value: " + context.getCurrentXmlTest().getParameter("browserName"));
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature, ITestContext context) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
        ExtentManager.getReporter().flush();
		afterTest();
	}

	//@AfterTest
	public void afterTest(){
		ITestContext context = configurationManager.getITestContext();
		String browserName = context.getCurrentXmlTest().getParameter("browserName");
		if(browserName.contains("remote") || browserName.contains("Remote")){
			WebDriver driver=configurationManager.getRemoteWebDriver();
			if(driver != null){
				driver.quit();
				configurationManager.setRemoteWebDriverMap(null);
			}
		} else {
			WebDriver driver=configurationManager.getWebDriver();
			if(driver != null){
				driver.quit();
				configurationManager.setWebDriverMap(null);
			}
		}
	}
}
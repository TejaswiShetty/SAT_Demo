package commonFunctions;

import java.io.*;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import com.relevantcodes.extentreports.Configuration;
import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.apache.commons.io.FileUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTabStop;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTabJc;

import static org.apache.poi.hslf.model.textproperties.TextPropCollection.TextPropType.paragraph;

public class CommonBehaviour {


	public String screenshot(WebDriver driver){
		String sFolderPath= configurationManager.getScreenShotPath();
		Integer number=0;
		try{
            number=new File(sFolderPath).listFiles().length;
        } catch (Exception ex){
		    number=0;
        }
		String sFilePath = sFolderPath + "\\"+ Integer.toString(number) + ".png";
		getScreenShot(driver, sFilePath);
		return sFilePath;
    }

    public String screenshot(RemoteWebDriver driver){
        String sFolderPath= configurationManager.getScreenShotPath();
        Integer number=0;
        try{
            number=new File(sFolderPath).listFiles().length;
        } catch (Exception ex){
            number=0;
        }
		String sFilePath = sFolderPath + "\\"+ Integer.toString(number) + ".png";
        getScreenShot(driver, sFilePath);
        return sFilePath;
    }

    public String reportScreenshot(WebDriver driver){
        String sFilePath = screenshot(driver);
        ExtentTestManager.addScreenShots(sFilePath);
        return sFilePath;
    }

    public String reportScreenshot(RemoteWebDriver driver){
        String sFilePath = screenshot(driver);
        ExtentTestManager.addScreenShots(sFilePath);
        return sFilePath;
    }

    public boolean imageDocumentReport() {
        String sFilePath=imageDocument();
		File file= new File(sFilePath);
        ExtentTestManager.getTest().log(LogStatus.INFO, "Complete screenshot path" , file.getAbsolutePath());
        return true;
    }

	public String imageDocument () {
        String sFolderPath= configurationManager.getScreenShotPath();
        String sFilePath = sFolderPath + "screenShots.docx";
        FileOutputStream out;
        Integer number=0;
        XWPFDocument docx = new XWPFDocument();
        XWPFParagraph par = docx.createParagraph();
        XWPFRun run = par.createRun();
        run.setText("Test case name is ..." + configurationManager.getTestCaseName());
        run.setFontSize(13);

		par = docx.createParagraph();
		run=par.createRun();
		run.setText("Screen shots path is ... " + sFolderPath);

		CTSectPr sectPr = docx.getDocument().getBody().addNewSectPr();
		XWPFHeaderFooterPolicy headerFooterPolicy = new XWPFHeaderFooterPolicy(docx, sectPr);
		XWPFHeader header = headerFooterPolicy.createHeader(XWPFHeaderFooterPolicy.DEFAULT);

		par= header.createParagraph();
		par.setAlignment(ParagraphAlignment.LEFT);

		CTTabStop tabStop = par.getCTP().getPPr().addNewTabs().addNewTab();
		tabStop.setVal(STTabJc.RIGHT);
		int twipsPerInch =  1440;
		tabStop.setPos(BigInteger.valueOf(6 * twipsPerInch));

		run = par.createRun();
		run.setText("Infosys");
		run.addTab();
		try{
            number=new File(sFolderPath).listFiles().length;
        }catch (Exception ex){
            number=0;
        }

        try{
            out = new FileOutputStream(sFilePath);
        } catch (IOException ex){
            System.out.println(ex.getMessage());
            return "";
        }

        for(int i=0; i<number ; i++){
            try{
				par = docx.createParagraph();
				run = par.createRun();
				String imgFile= sFolderPath + Integer.toString(i) + ".png";
				InputStream pic = new FileInputStream(imgFile);
                run.addPicture(pic, Document.PICTURE_TYPE_PNG, imgFile, Units.toEMU(450), Units.toEMU(350));
				pic.close();
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        }

        try{
			XWPFFooter footer = headerFooterPolicy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);
			par = footer.createParagraph();
			par.setAlignment(ParagraphAlignment.CENTER);

			run = par.createRun();
			run.setText("Automation Tester : Vinay Kumar Pulabaigari (Emp No: 660386)");
			docx.write(out);
			out.close();
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
            return "";
        }
        return sFilePath;
    }

    public void checkTitle(final WebDriver driver, String expectedTitle) {
        if(driver.getTitle().equals(expectedTitle)) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "Check page title", "Page title is " + expectedTitle);
        } else {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Check page title", "Incorrect login page title " + driver.getTitle());
        }
    }

    public void checkTitle(final RemoteWebDriver driver, String expectedTitle) {
        if(driver.getTitle().equals(expectedTitle)) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "Check page title", "Page title is " + expectedTitle);
        } else {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Check page title", "Incorrect login page title " + driver.getTitle());
        }
    }

	public boolean isExist(final WebDriver driver, final By locator) {
		try{
    		WebDriverWait wait = new WebDriverWait(driver, 15);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return element.isDisplayed();
        }catch(Exception ex){
            return false;
        }
	}


	public boolean isExist(final RemoteWebDriver driver, final By locator) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return element.isDisplayed();
		}catch(Exception ex){
			return false;
		}
    }

	public boolean isClickable(final WebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		return element.isEnabled();
	}

	public boolean isClickable(final RemoteWebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		return element.isEnabled();
	}

	public boolean isSelectable(final WebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		return wait.until(ExpectedConditions.elementToBeSelected(locator));
	}

	public boolean isSelectable(final RemoteWebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		return wait.until(ExpectedConditions.elementToBeSelected(locator));
	}

	public Date stringToDate(String formatter, String value) {
		DateFormat df = new SimpleDateFormat(formatter);
		Date startDate = null;
		try {
			startDate = df.parse(value);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return startDate;
	}

	public boolean click(String fieldName, By by, RemoteWebDriver driver) {
		try {
			if (isClickable(driver, by)) {
				driver.findElement(by).click();
				ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been clicked successfully.");
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been clicked.");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been clicked.");
			return false;
		}
	}

	public boolean jClick(String fieldName, By by, RemoteWebDriver driver) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = driver;
			executor.executeScript("arguments[0].click();", element);
			ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been clicked successfully.");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been clicked.");
			return false;
		}
	}

	public boolean type(String fieldName, By by, RemoteWebDriver driver, String message) {
		try {
			if (driver.findElement(by).isEnabled()) {
				driver.findElement(by).sendKeys(message);
				ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been entered with " + message);
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been entered with " + message);
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been entered with " + message);
			return false;
		}
	}

	public boolean jType(String fieldName, By by, RemoteWebDriver driver, String message) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = driver;
			executor.executeScript("arguments[0].setAttribute('value', '" + message + "')", element);
			ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been entered with " + message);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been entered with " + message);
			return false;
		}
	}

	public boolean selectValue(String fieldName,By by, RemoteWebDriver driver, String message) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				boolean flag=false;
				try {
					dropdown.selectByValue(message);
					ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected by " + message);
					flag=true;
				} catch (Exception e) {
					e.printStackTrace();
					for (int i = 0; i < dropdown.getOptions().size(); i++) {
						if (dropdown.getOptions().get(i).getText().trim().equalsIgnoreCase(message.trim())) {
							dropdown.selectByIndex(i);
							ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected by " + message);
							flag=true;
							break;
						}
					}
				}
				if(flag!=true) {
					ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has not been selected by " + message);
				}
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has not been selected by " + message);
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has not been selected by " + message);
			return false;
		}
	}

	public boolean selectByIndex(String fieldName, By by, RemoteWebDriver driver, int index) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				dropdown.selectByIndex(index);
				ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected with a index: " + index);
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected with a index: " + index);
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected with a index: " + index);
			return false;
		}
	}

	public boolean click(String fieldName, By by, WebDriver driver) {
		try {
			if (isClickable(driver, by)) {
				driver.findElement(by).click();
				ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been a clicked.");
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
			return false;
		}
	}

	public boolean jClick(String fieldName, By by, WebDriver driver) {
		try {
			if (isClickable(driver, by)) {
				WebElement element = driver.findElement(by);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
				ExtentTestManager.write(LogStatus.PASS, "Click", fieldName + " has been a clicked.");
				return true;
			}else {
				ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
			return false;
		}
	}

	public boolean type(String fieldName, By by, WebDriver driver, String message) {
		try{
			int count =0;
			while(!isExist(driver, by)){
				count=count+1;
				if(count > 60){
					break;
				}
			}
		}catch(Exception ex){

		}
		try {
			if (driver.findElement(by).isEnabled()) {
				driver.findElement(by).sendKeys(message);
				ExtentTestManager.write(LogStatus.PASS, "Type" , fieldName +  " has been entered with a message :" + message);
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
			return false;
		}
	}

	public boolean jType(String fieldName, By by, WebDriver driver, String message) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].setAttribute('value', '" + message + "')", element);
			ExtentTestManager.write(LogStatus.PASS, "Type" , fieldName +  " has been entered with a message :" + message);
			return true;
		} catch (Exception e) {
			ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
			e.printStackTrace();
			return false;
		}
	}

	public boolean selectValue(String fieldName,By by, WebDriver driver, String message) {
		try {
			//if (isSelectable(driver, by)) {
				boolean flag=false;
				Select dropdown = new Select(driver.findElement(by));
				try {
					dropdown.selectByValue(message);
					ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected by " + message);
					flag=true;
				} catch (Exception e) {
					e.printStackTrace();
					for (int i = 0; i < dropdown.getOptions().size(); i++) {
						if (dropdown.getOptions().get(i).getText().trim().equalsIgnoreCase(message.trim())) {

							dropdown.selectByIndex(i);

							ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected by " + message);
							flag=true;
							break;
						}
					}
				}
				if(flag!=true){
					ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected by " + message);
				}
				return true;
			//} else {
			//	ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected by " + message);
			//	return false;
			//}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected by " + message);
			return false;
		}
	}

	public boolean selectByIndex(String fieldName, By by, WebDriver driver, int index) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				dropdown.selectByIndex(index);
				ExtentTestManager.write(LogStatus.PASS, "Select" , fieldName +  " has been selected with a index: " + index);
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected with a index: " + index);
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Select" , fieldName +  " has NOT been selected with a index: " + index);
			return false;
		}
	}

	public String getAttribute(By by, WebDriver driver, String attribute) {
		String returnValue = "";
		try {
			if (isSelectable(driver, by)) {
				returnValue = driver.findElement(by).getAttribute(attribute);
				return returnValue;
			} else {
				return returnValue;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return returnValue;
		}
	}

	public String getAttribute(By by, RemoteWebDriver driver, String attribute) {
		String returnValue = "";
		try {
			if (isSelectable(driver, by)) {
				returnValue = driver.findElement(by).getAttribute(attribute);
				return returnValue;
			} else {
				return returnValue;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return returnValue;
		}
	}

	public boolean getScreenShot(WebDriver driver, String fileName) {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// The below method will save the screen shot in d drive with name
		// "screenshot.png"
		try {
			FileUtils.copyFile(scrFile, new File(fileName));
		} catch (IOException e) {
			System.out.println("Exception is "+ e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean getScreenShot(RemoteWebDriver driver, String fileName) {
		WebDriver augmentedDriver = new Augmenter().augment(driver);
		File scrFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(fileName));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean navigateURL(WebDriver driver, String url) {
		driver.get(url);
		return true;
	}

	public boolean navigateURL(RemoteWebDriver driver, String url) {
		driver.get(url);
		return true;
	}

	public String getTitle(WebDriver driver) {
		return driver.getTitle();
	}

	public String getTitle(RemoteWebDriver driver) {
		return driver.getTitle();
	}

	public boolean passTab(String s, By by, WebDriver driver) {
        try {
            if (driver.findElement(by).isEnabled()) {
                driver.findElement(by).sendKeys(Keys.TAB);
                ExtentTestManager.write(LogStatus.PASS, "TAB button pressed");
                return true;
            } else {
                ExtentTestManager.write(LogStatus.FAIL, "TAB button not pressed");
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            ExtentTestManager.write(LogStatus.FAIL, "TAB button not pressed");
            return false;
        }
	}

    public void explicitWait(int timeInSec){
        try {
            int timeInMillisec = timeInSec*1000;
            Thread.sleep(timeInMillisec);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }
}

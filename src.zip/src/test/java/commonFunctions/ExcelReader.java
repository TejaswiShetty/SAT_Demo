package commonFunctions;

import java.io.*;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.google.common.io.Files;
import java.util.HashMap;
import java.util.Properties;
import extentReport.ExtentTestManager;
import com.relevantcodes.extentreports.LogStatus;

public class ExcelReader {
	private String environment;
    private Map<String, String> mDataRow = new HashMap<String, String>();
	public void setEnvironment(String env){
	    this.environment = env;
    }

    public String getEnvironment(){
        return this.environment;
    }

    private String fileName() {
        String fileName="";
        Properties prop = new Properties();
        InputStream input;
        try{
            input = new FileInputStream("resources/testDataConfigure.properties");
            prop.load(input);
        } catch (Exception ex){
            System.out.println("Test data configuration file has been found, and exception is " + ex.getMessage() );
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test data configuraion file has been found, and exception is " + ex.getMessage());
            return fileName;
        }
        try{
            fileName = System.getProperty("user.dir") + prop.getProperty("UAT.testdataWorkBook");
        } catch (Exception ex){
            System.out.println("Test data workbook field hasn't been found, and exception is " + ex.getMessage());
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test data workbook field hasn't been found, and exception is " + ex.getMessage());
            return fileName;
        }
        return fileName;
    }

    private String sheetName() {
        String sheetName="";
        Properties prop = new Properties();
        InputStream input;
        try{
            input = new FileInputStream("resources/testDataConfigure.properties");
            prop.load(input);
        } catch (Exception ex){
            System.out.println("Test data configuration file has been found, and exception is " + ex.getMessage());
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test data configuration file has been found, and exception is " + ex.getMessage());
            return sheetName;
        }
        try{
            sheetName = prop.getProperty("UAT.testdataSheet");
        } catch (Exception ex){
            System.out.println("Test data sheet field hasn't been found, and exception is " + ex.getMessage());
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test data sheet field hasn't been found, and exception is " + ex.getMessage());
            return sheetName;
        }
        return sheetName;
    }

    @SuppressWarnings("deprecation")
    private boolean readData(String testCaseName){
        int iRowNumber = -1;
        FileInputStream inputStream;
        Workbook workbook = null;
        Sheet firstSheet = null;
        String sFileName, sSheetName;

        sFileName=fileName();
        sSheetName=sheetName();

        try {
            inputStream = new FileInputStream(new File(sFileName));
            if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xls")) {
                workbook = new HSSFWorkbook(inputStream);
            } else if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xlsx")) {
                workbook = new XSSFWorkbook(inputStream);
            }

            int sheetNumber = workbook.getNameIndex(sSheetName);
            if (sheetNumber == -1) {
                ExtentTestManager.getTest().log(LogStatus.INFO,
                        "Provided sheet name is : " + sSheetName + " is not there in the  file path" + sFileName);
                ExtentTestManager.getTest().log(LogStatus.INFO, " Reading from first sheet");
                firstSheet = workbook.getSheetAt(0);
            } else {
                firstSheet = workbook.getSheetAt(sheetNumber);
            }

        } catch (FileNotFoundException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Provided file path: " + sFileName + " is Invalied");
            ExtentTestManager.getTest().log(LogStatus.INFO, "File Not Found Exception details" + e.toString());
            return false;
        } catch (IOException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL,
                    "Provided file is : " + sFileName + " is not in a read mode");
            ExtentTestManager.getTest().log(LogStatus.INFO, "IO Exception details" + e.toString());
            return false;
        }

        for (int x = 0; x < firstSheet.getPhysicalNumberOfRows(); x++) {
            String rowTestCaseName=firstSheet.getRow(x).getCell(1).getStringCellValue();
            if(rowTestCaseName.trim().equals(testCaseName) || rowTestCaseName.trim().equalsIgnoreCase(testCaseName)){
                iRowNumber=x;
                break;
            }
        }

        if (iRowNumber == -1) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test case name:" + testCaseName
                    + " is not found in the test data file :" + sFileName + ", Sheet Name is " + sSheetName);
            return false;
        }
        Row row = firstSheet.getRow(iRowNumber);
        Row firstRow =firstSheet.getRow(0);
        for (int y = 0; y < row.getPhysicalNumberOfCells(); y++) {
            Cell cell = row.getCell(y);
            String data="";
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    System.out.print(cell.getStringCellValue());
                    data = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    System.out.print(cell.getBooleanCellValue());
                    if (cell.getBooleanCellValue()) {
                        data= "True";
                    } else {
                        data= "False";
                    }
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    System.out.print(cell.getNumericCellValue());
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_FORMULA:
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BLANK:
                    data= "";
                    break;
                default:
                    data= "";
                    break;
            }
            mDataRow.put(firstRow.getCell(y).getStringCellValue().trim(), data);
        }
        return true;
    }

    @SuppressWarnings("deprecation")
    public Map<String, String>   readDataReturnMap(String testCaseName){
        int iRowNumber = -1;
        FileInputStream inputStream;
        Workbook workbook = null;
        Sheet firstSheet = null;
        String sFileName, sSheetName;

        sFileName=fileName();
        sSheetName=sheetName();

        try {
            inputStream = new FileInputStream(new File(sFileName));
            if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xls")) {
                try{
                    workbook = WorkbookFactory.create(new File(sFileName));
                } catch(InvalidFormatException EX){
                    ExtentTestManager.getTest().log(LogStatus.FAIL, "Provided file path: " + sFileName + " is Invalied");
                    ExtentTestManager.getTest().log(LogStatus.INFO, "File Not Found Exception details" + EX.toString());
                    return null;
                }
//                workbook = new HSSFWorkbook(inputStream);
            } else if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xlsx")) {
                workbook = new XSSFWorkbook(inputStream);
            }

            int sheetNumber = -1;
            for(int i=0; i<workbook.getNumberOfSheets();i++){
                if(workbook.getSheetName(i).equalsIgnoreCase(sSheetName)){
                    sheetNumber=i;
                    break;
                }
            }

            if (sheetNumber == -1) {
                ExtentTestManager.getTest().log(LogStatus.INFO,
                        "Provided sheet name is : " + sSheetName + " is not there in the  file path" + sFileName);
                ExtentTestManager.getTest().log(LogStatus.INFO, " Reading from first sheet");
                firstSheet = workbook.getSheetAt(0);
            } else {
                firstSheet = workbook.getSheetAt(sheetNumber);
            }

        } catch (FileNotFoundException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Provided file path: " + sFileName + " is Invalied");
            ExtentTestManager.getTest().log(LogStatus.INFO, "File Not Found Exception details" + e.toString());
            return null;
        } catch (IOException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL,
                    "Provided file is : " + sFileName + " is not in a read mode");
            ExtentTestManager.getTest().log(LogStatus.INFO, "IO Exception details" + e.toString());
            return null;
        }

        for (int x = 0; x < firstSheet.getPhysicalNumberOfRows(); x++) {
            String rowTestCaseName=firstSheet.getRow(x).getCell(0).getStringCellValue();
            if(rowTestCaseName.trim().equals(testCaseName) || rowTestCaseName.trim().equalsIgnoreCase(testCaseName)){
                iRowNumber=x;
                break;
            }
        }

        if (iRowNumber == -1) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test case name:" + testCaseName
                    + " is not found in the test data file :" + sFileName + ", Sheet Name is " + sSheetName);
            return null;
        }
        Row row = firstSheet.getRow(iRowNumber);
        Row firstRow =firstSheet.getRow(0);
        for (int y = 0; y < row.getPhysicalNumberOfCells(); y++) {
            Cell cell = row.getCell(y);
            String data="";
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    System.out.print(cell.getStringCellValue());
                    data = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    System.out.print(cell.getBooleanCellValue());
                    if (cell.getBooleanCellValue()) {
                        data= "True";
                    } else {
                        data= "False";
                    }
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    System.out.print(cell.getNumericCellValue());
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_FORMULA:
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BLANK:
                    data= "";
                    break;
                default:
                    data= "";
                    break;
            }
            mDataRow.put(firstRow.getCell(y).getStringCellValue().trim(), data);
        }
        return mDataRow;
    }

     @SuppressWarnings("deprecation")
    public Map<String, String>  readData(String sFileName, String sSheetName,String testCaseName){
        int iRowNumber = -1;
        FileInputStream inputStream;
        Workbook workbook = null;
        Sheet firstSheet = null;
        try {
            inputStream = new FileInputStream(new File(sFileName));
            if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xls")) {
                workbook = new HSSFWorkbook(inputStream);
            } else if (Files.getFileExtension(sFileName).trim().equalsIgnoreCase("xlsx")) {
                workbook = new XSSFWorkbook(inputStream);
            }

            int sheetNumber = workbook.getNameIndex(sSheetName);
            if (sheetNumber == -1) {
                ExtentTestManager.getTest().log(LogStatus.INFO,
                        "Provided sheet name is : " + sSheetName + " is not there in the  file path" + sFileName);
                ExtentTestManager.getTest().log(LogStatus.INFO, " Reading from first sheet");
                firstSheet = workbook.getSheetAt(0);
            } else {
                firstSheet = workbook.getSheetAt(sheetNumber);
            }

        } catch (FileNotFoundException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Provided file path: " + sFileName + " is Invalied");
            ExtentTestManager.getTest().log(LogStatus.INFO, "File Not Found Exception details" + e.toString());
            return null;
        } catch (IOException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL,
                    "Provided file is : " + sFileName + " is not in a read mode");
            ExtentTestManager.getTest().log(LogStatus.INFO, "IO Exception details" + e.toString());
            return null;
        }

        for (int x = 0; x < firstSheet.getPhysicalNumberOfRows(); x++) {
            String rowTestCaseName=firstSheet.getRow(x).getCell(1).getStringCellValue();
            if(rowTestCaseName.trim().equals(testCaseName) || rowTestCaseName.trim().equalsIgnoreCase(testCaseName)){
                iRowNumber=x;
                break;
            }
        }

        if (iRowNumber == -1) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test case name:" + testCaseName
                    + " is not found in the test data file :" + sFileName + ", Sheet Name is " + sSheetName);
            return null;
        }
        Row row = firstSheet.getRow(iRowNumber);
        Row firstRow =firstSheet.getRow(0);
        for (int y = 0; y < row.getPhysicalNumberOfCells(); y++) {
            Cell cell = row.getCell(y);
            String data="";
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    System.out.print(cell.getStringCellValue());
                    data = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    System.out.print(cell.getBooleanCellValue());
                    if (cell.getBooleanCellValue()) {
                        data= "True";
                    } else {
                        data= "False";
                    }
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    System.out.print(cell.getNumericCellValue());
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_FORMULA:
                    data= cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BLANK:
                    data= "";
                    break;
                default:
                    data= "";
                    break;
            }
            mDataRow.put(firstRow.getCell(y).getStringCellValue().trim(), data);
        }
        return mDataRow;
    }

    public Map<String, String> getMap() {
        return mDataRow;
    }

	public String getStringFromMap(String columnName) {
        if (mDataRow.get(columnName.trim()).isEmpty() || mDataRow.get(columnName.trim()) == null) {
            ExtentTestManager.getTest().log(LogStatus.INFO, "Column  hasn't been found, hence the value is going to be returned is blank.");
			return "";
		} else {
			return mDataRow.get(columnName.trim());
		}
	}
}

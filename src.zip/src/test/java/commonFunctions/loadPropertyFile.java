package commonFunctions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by Vinay on 6/14/2017.
 */
public class loadPropertyFile {
    // Property read variables
    private Properties prop = new Properties();
    private InputStream input = null;
    public loadPropertyFile(String fileName){
        String sFileName = System.getProperty("user.dir") + fileName;
        try {
            input = new FileInputStream(sFileName);
            prop.load(input);
        } catch (FileNotFoundException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL,
                    "Provided property file path: " + sFileName + " is Invalied");
            ExtentTestManager.getTest().log(LogStatus.INFO, "File Not Found Exception details" + e.toString());
        } catch (IOException e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL,
                    "Provided peroperty file is : " + sFileName + " is not in a read mode");
            ExtentTestManager.getTest().log(LogStatus.INFO, "IO Exception details" + e.toString());
        }
    }

    public String getPropertyValue(String parameterName){
        String value="";
        try{
            value= prop.getProperty(parameterName);
        } catch (Exception ex){

        }
        return value;
    }
}

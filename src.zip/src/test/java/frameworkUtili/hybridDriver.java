package frameworkUtili;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Created by Vinay on 6/21/2017.
 */
public class hybridDriver extends RemoteWebDriver{
}

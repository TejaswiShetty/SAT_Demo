package frameworkUtili;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import java.util.HashMap;
import java.util.Map;

public class excelTestDataUtil {
    private static Map<Integer,Map<String, String>> dataList = new HashMap<>();

    public static synchronized void setDataList(Map<String, String> map){
        dataList.put((int) (long) (Thread.currentThread().getId()), map);
    }

    public static synchronized String getDataList(String columnName){
        Map<String, String> mDataRow = dataList.get((int) (long) (Thread.currentThread().getId()));

        if (mDataRow.get(columnName.trim()).isEmpty() || mDataRow.get(columnName.trim()) == null) {
            ExtentTestManager.getTest().log(LogStatus.INFO, "Column  hasn't been found, hence the value is going to be returned is blank.");
            return "";
        } else {
            return mDataRow.get(columnName.trim());
        }
    }
}
